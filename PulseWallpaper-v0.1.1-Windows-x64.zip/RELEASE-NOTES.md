# Pulse Wallpaper v0.1.1

- Choose a fresh program folder on a fixed local drive. Setup defaults to the current user's LocalAppData Programs folder.
- Accept the Music access and privacy terms before setup installs files.
- Choose the cassette widget with two spinning reels and use colors from available cover artwork.
- Open **System → Check for updates** or enable daily checks and optional automatic installation in a configured build.
- Use the same published Microsoft Edge extension for audio capture. Browser artwork, video, automatic tab detection and extra sites are planned separately.

The GitHub channel and publisher verification key are configured. Test live installation and a signed update on Windows before publishing.

Existing v0.1.0 users install the full new version once. If the installer detects v0.1.0, uninstall it in Windows first. Pulse stores the public settings and imported wallpaper packs in the user profile. Future public patches target v0.1.1 and later in place.
